<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

require_once __DIR__ . '/include/db_con.php';

try {

    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {

    die("DB Error: " . $e->getMessage());
}

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$username  = $_SESSION['username'];
$role_type = $_SESSION['role_type'];

$rootPath = 'storage/';
if (!file_exists($rootPath)) {
    mkdir($rootPath, 0777, true);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // File Upload
    if (isset($_FILES['files'])) {

        $targetDir = $rootPath . trim($_POST['target_folder'] ?? '');

        $response = [];

        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }

        foreach ($_FILES['files']['name'] as $key => $name) {

            $tmp = $_FILES['files']['tmp_name'][$key];
            $targetFile = rtrim($targetDir, '/') . '/' . basename($name);

            if (!is_uploaded_file($tmp)) {
                $response[] = [
                    'status' => 'error',
                    'file' => $name,
                    'msg' => 'invalid upload'
                ];
                continue;
            }

            if (move_uploaded_file($tmp, $targetFile)) {
                $response[] = [
                    'status' => 'success',
                    'file' => $name
                ];
            } else {
                $response[] = [
                    'status' => 'error',
                    'file' => $name,
                    'msg' => 'move failed'
                ];
            }
        }

        echo json_encode($response);
        exit();
    }

    // Stats
    if (isset($_POST['action']) && $_POST['action'] == 'get_stats') {
        $fNames = [];
        $fCounts = [];
        $totalF = 0;
        $dirs = array_filter(glob($rootPath . '*'), 'is_dir');
        foreach ($dirs as $dir) {
            $fNames[] = basename($dir);
            $c = count(scandir($dir)) - 2;
            $fCounts[] = ($c < 0) ? 0 : $c;
            $totalF++;
        }
        $free  = disk_free_space($rootPath);
        $total = disk_total_space($rootPath);
        $usedP = round((($total - $free) / $total) * 100, 1);
        $usedS = ($total - $free);
        echo json_encode([
            'folderNames'       => $fNames,
            'fileCounts'        => $fCounts,
            'totalFolders'      => $totalF,
            'usedPercent'       => $usedP,
            'usedSizeFormatted' => formatSize($usedS),
            'totalSizeFormatted' => formatSize($total)
        ]);
        exit();
    }


    // root folders
    if (isset($_POST['action']) && $_POST['action'] == 'ms_list_root') {
        $folders = [];
        $dirs = array_filter(glob($rootPath . '*'), 'is_dir');
        foreach ($dirs as $dir) {
            $name  = basename($dir);
            $files = array_values(array_diff(scandir($dir), ['.', '..']));
            $subfolders = 0;
            $fileCount = 0;
            foreach ($files as $item) {
                if (is_dir($dir . '/' . $item)) {
                    $subfolders++;
                } else {
                    $fileCount++;
                }
            }
            $folders[] = ['name' => $name, 'count' => $fileCount, 'subfolders' => $subfolders];
        }
        echo json_encode(['folders' => $folders]);
        exit();
    }

    // List files inside a folder
    if (isset($_POST['action']) && $_POST['action'] == 'ms_list_files') {
        $folder = basename($_POST['folder']);
        $path   = $rootPath . $folder . '/';
        if (!is_dir($path)) {
            echo json_encode(['error' => 'Not found']);
            exit();
        }
        $items = [];
        foreach (array_diff(scandir($path), ['.', '..']) as $f) {
            $fp = $path . $f;
            $items[] = [
                'name'    => $f,
                'size'    => is_dir($fp) ? '-' : formatSize(filesize($fp)),
                'is_dir'  => is_dir($fp),
                'mtime'   => date('Y-m-d H:i', filemtime($fp)),
                'path'    => $folder . '/' . $f
            ];
        }
        echo json_encode(['files' => $items, 'folder' => $folder]);
        exit();
    }

    // Create folder 
    if (isset($_POST['action']) && $_POST['action'] == 'ms_create_folder') {
        $parent    = trim($_POST['parent'] ?? '');
        $newFolder = basename(trim($_POST['name']));
        if ($newFolder === '') {
            echo json_encode(['error' => 'Invalid name']);
            exit();
        }
        $target = $rootPath . ($parent ? $parent . '/' : '') . $newFolder;
        if (file_exists($target)) {
            echo json_encode(['error' => 'Already exists']);
            exit();
        }
        mkdir($target, 0777, true);
        echo json_encode(['success' => true]);
        exit();
    }

    // Delete folder
    if (isset($_POST['action']) && $_POST['action'] == 'ms_delete_folder') {
        $folder = basename($_POST['folder']);
        $path   = $rootPath . $folder;
        if (!is_dir($path)) {
            echo json_encode(['error' => 'Not found']);
            exit();
        }
        rmdirRecursive($path);
        echo json_encode(['success' => true]);
        exit();
    }

    // Delete multiple files
    if (isset($_POST['action']) && $_POST['action'] == 'ms_delete_files') {
        $folder = basename($_POST['folder']);
        $files  = json_decode($_POST['files'], true);
        $success = true;
        foreach ($files as $file) {
            $file = basename($file);
            $fp = $rootPath . $folder . '/' . $file;
            if (file_exists($fp) && !is_dir($fp)) {
                if (!unlink($fp)) $success = false;
            }
        }
        echo json_encode(['success' => $success]);
        exit();
    }

    // Move multiple files to another folder
    if (isset($_POST['action']) && $_POST['action'] == 'ms_move_files') {
        $srcFolder  = basename($_POST['src_folder']);
        $destFolder = basename($_POST['dest_folder']);
        $files      = json_decode($_POST['files'], true);
        $success = true;

        if (!is_dir($rootPath . $destFolder)) {
            echo json_encode(['error' => 'Destination not found']);
            exit();
        }

        foreach ($files as $file) {
            $file = basename($file);
            $src  = $rootPath . $srcFolder . '/' . $file;
            $dest = $rootPath . $destFolder . '/' . $file;
            if (file_exists($src) && !is_dir($src)) {
                if (!rename($src, $dest)) $success = false;
            }
        }
        echo json_encode(['success' => $success]);
        exit();
    }

    // ── USERS CONTROL ─────────────────────

    if ($role_type != 1 && isset($_POST['action']) && str_starts_with($_POST['action'], 'uc_')) {

        echo json_encode([
            'error' => 'Access denied'
        ]);

        exit();
    }

    // Users List 
    if (isset($_POST['action']) && $_POST['action'] == 'uc_list_users') {

        $stmt = $pdo->query("
        SELECT
            id,
            username,
            role_type,
            last_login,
            created_at
        FROM users
        ORDER BY id DESC
    ");

        echo json_encode([
            'success' => true,
            'users' => $stmt->fetchAll()
        ]);

        exit();
    }

    // Add User
    if (isset($_POST['action']) && $_POST['action'] == 'uc_add_user') {

        $username  = trim($_POST['username'] ?? '');
        $password  = trim($_POST['password'] ?? '');
        $role_type = (int)($_POST['role_type'] ?? 2);

        if ($username == '' || $password == '') {

            echo json_encode([
                'error' => 'All fields required'
            ]);

            exit();
        }

        $check = $pdo->prepare("
        SELECT id
        FROM users
        WHERE username = ?
        LIMIT 1
    ");

        $check->execute([$username]);

        if ($check->fetch()) {

            echo json_encode([
                'error' => 'Username already exists'
            ]);

            exit();
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $pdo->prepare("
        INSERT INTO users (
            username,
            password,
            role_type
        )
        VALUES (?, ?, ?)
    ");

        $stmt->execute([
            $username,
            $hashedPassword,
            $role_type
        ]);

        echo json_encode([
            'success' => true
        ]);

        exit();
    }

    // Delete User
    if (isset($_POST['action']) && $_POST['action'] == 'uc_delete_user') {

        $id = (int)($_POST['id'] ?? 0);

        if ($id == $_SESSION['user_id']) {

            echo json_encode([
                'error' => 'You cannot delete yourself'
            ]);

            exit();
        }

        $stmt = $pdo->prepare("
        DELETE FROM users
        WHERE id = ?
    ");

        $stmt->execute([$id]);

        echo json_encode([
            'success' => true
        ]);

        exit();
    }

    // Change Password
    if (isset($_POST['action']) && $_POST['action'] == 'uc_change_password') {

        $id       = (int)($_POST['id'] ?? 0);
        $password = trim($_POST['password'] ?? '');

        if ($password == '') {

            echo json_encode([
                'error' => 'Password required'
            ]);

            exit();
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $pdo->prepare("
        UPDATE users
        SET password = ?
        WHERE id = ?
    ");

        $stmt->execute([
            $hashedPassword,
            $id
        ]);

        echo json_encode([
            'success' => true
        ]);

        exit();
    }

    // Change Role
    if (isset($_POST['action']) && $_POST['action'] == 'uc_change_role') {

        $id   = (int)($_POST['id'] ?? 0);
        $role = (int)($_POST['role'] ?? 2);

        if ($id == $_SESSION['user_id']) {

            echo json_encode([
                'error' => 'You cannot change your own role'
            ]);

            exit();
        }

        $stmt = $pdo->prepare("
        UPDATE users
        SET role_type = ?
        WHERE id = ?
    ");

        $stmt->execute([
            $role,
            $id
        ]);

        echo json_encode([
            'success' => true
        ]);

        exit();
    }
    if (isset($_POST['action']) && $_POST['action'] == 'uc_folder_list') {

        $dirs = array_filter(glob($rootPath . '*'), 'is_dir');

        $folders = [];

        foreach ($dirs as $dir) {
            $folders[] = basename($dir);
        }

        echo json_encode([
            'folders' => $folders
        ]);

        exit();
    }
}

// ── Page-load data ─────────────────────────────────────────────────────────────
$folderNames  = [];
$fileCounts   = [];
$totalFolders = 0;
$directories  = array_filter(glob($rootPath . '*'), 'is_dir');

foreach ($directories as $dir) {
    $folderNames[] = basename($dir);
    $files         = scandir($dir);
    $count         = count($files) - 2;
    $fileCounts[]  = ($count < 0) ? 0 : $count;
    $totalFolders++;
}

$freeSpace   = disk_free_space($rootPath);
$totalSpace  = disk_total_space($rootPath);
$usedSpace   = $totalSpace - $freeSpace;
$usedPercent = round(($usedSpace / $totalSpace) * 100, 1);

function formatSize($bytes)
{
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    for ($i = 0; $bytes > 1024; $i++) $bytes /= 1024;
    return round($bytes, 2) . ' ' . $units[$i];
}

function rmdirRecursive($dir)
{
    foreach (array_diff(scandir($dir), ['.', '..']) as $item) {
        $p = $dir . '/' . $item;
        is_dir($p) ? rmdirRecursive($p) : unlink($p);
    }
    rmdir($dir);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Dashboard | Media Server</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        /* ── ALL ORIGINAL STYLES (unchanged) ─────────────────────────────── */
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f4f7f9;
            margin: 0;
            overflow-x: hidden;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: #1a1a2e;
            color: white;
            z-index: 1000;
            transition: all 0.3s ease;
        }

        .sidebar a {
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            padding: 15px 25px;
            display: block;
            border-left: 4px solid transparent;
            transition: 0.2s;
            cursor: pointer;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: rgba(233, 69, 96, 0.1);
            color: #e94560;
            border-left: 4px solid #e94560;
        }

        .main-content {
            margin-left: 280px;
            padding: 40px;
            transition: 0.3s;
        }

        .content-section {
            display: none;
        }

        .content-section.active {
            display: block;
            animation: fadeIn 0.3s ease-in;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        .upload-area {
            border: 2px dashed #e94560;
            border-radius: 15px;
            padding: 40px;
            text-align: center;
            background: rgba(233, 69, 96, 0.05);
            cursor: pointer;
            transition: 0.3s;
        }

        .upload-area:hover {
            background: rgba(233, 69, 96, 0.1);
        }

        .file-list-item {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            position: relative;
        }

        .status-completed {
            color: #198754;
            font-weight: bold;
        }

        .remove-btn {
            color: #6c757d;
            cursor: pointer;
            transition: 0.2s;
        }

        .remove-btn:hover {
            color: #dc3545;
            transform: scale(1.2);
        }

        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .main-content {
                margin-left: 0;
                padding: 20px;
            }

            .mobile-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                background: #1a1a2e;
                color: white;
                padding: 15px 20px;
                position: sticky;
                top: 0;
                z-index: 1100;
            }
        }

        .stat-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }

        .role-badge {
            font-size: 0.7rem;
            padding: 4px 10px;
            border-radius: 50px;
        }

        /* ── NEW: Manage Storage styles ───────────────────────────────────── */
        .ms-folder-card {
            background: #fff;
            border-radius: 12px;
            padding: 16px 20px;
            margin-bottom: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: box-shadow 0.2s;
        }

        .ms-folder-card:hover {
            box-shadow: 0 4px 14px rgba(0, 0, 0, 0.1);
        }

        .ms-folder-card .folder-name {
            font-weight: 600;
            cursor: pointer;
        }

        .ms-folder-card .folder-name:hover {
            color: #e94560;
        }

        .ms-file-row {
            background: #fff;
            border-radius: 10px;
            padding: 12px 16px;
            margin-bottom: 8px;
            box-shadow: 0 1px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .ms-file-row:hover {
            background: #f8f9fa;
        }

        .ms-file-checkbox {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        .ms-breadcrumb {
            font-size: 0.85rem;
            margin-bottom: 20px;
        }

        .ms-breadcrumb span {
            cursor: pointer;
            color: #e94560;
        }

        .ms-breadcrumb span:hover {
            text-decoration: underline;
        }

        #ms-toolbar {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            align-items: center;
        }

        .ms-empty {
            text-align: center;
            color: #aaa;
            padding: 40px 0;
        }

        .ms-batch-actions {
            background: #e94560;
            color: white;
            padding: 8px 15px;
            border-radius: 50px;
            display: inline-flex;
            gap: 10px;
            align-items: center;
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .ms-batch-actions button {
            background: white;
            border: none;
            border-radius: 20px;
            padding: 5px 12px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .ms-batch-actions button:first-child {
            color: #e94560;
        }

        .ms-batch-actions button:last-child {
            color: #dc3545;
        }

        .ms-select-all {
            cursor: pointer;
            user-select: none;
        }

        /* ── Mobile Menu Modern Style ── */
        #mobileMenu .offcanvas-body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            /* يوسّط عمودي */
            align-items: flex-start;
            height: 100%;
            padding-left: 30px;
        }

        #mobileMenu a {
            font-size: 1.2rem;
            /* تكبير الخط */
            font-weight: 600;
            padding: 5px 0;
            margin-bottom: 1px;
            /* مسافة بين الخيارات */
            transition: 0.2s ease;
        }

        #mobileMenu a:hover {
            transform: translateX(6px);
            color: #e94560;
        }

        #mobileMenu .text-danger {
            margin-top: 30px;
            font-weight: 700;
        }
    </style>
</head>

<body>

    <header class="mobile-header shadow d-lg-none">
        <h5 class="mb-0 fw-bold">Media <span style="color:#e94560">Server</span></h5>
        <button id="menuBtn" class="btn btn-outline-light border-0" type="button">
            <i id="menuIcon" class="bi bi-list fs-3"></i>
        </button>
    </header>

    <nav class="sidebar">
        <div class="p-4 text-center">
            <h4 class="fw-bold"><span style="color:#e94560">Media</span> Server</h4>
            <div class="mt-4 pt-2">
                <i class="bi bi-person-circle fs-1"></i>
                <div class="mt-2 fw-bold text-white"><?php echo htmlspecialchars($username); ?></div>
                <span class="badge <?php echo ($role_type == 1) ? 'bg-danger' : 'bg-primary'; ?> role-badge">
                    <?php echo ($role_type == 1) ? 'ADMINISTRATOR' : 'USER'; ?>
                </span>
            </div>
        </div>
        <div class="mt-4">
            <a onclick="showSection('dashboard')" id="nav-dashboard" class="active"><i class="bi bi-grid-1x2-fill me-3"></i> Dashboard</a>
            <?php if ($role_type == 1): ?>
                <small class="px-4 text-muted text-uppercase d-block mt-4 mb-2 fw-bold" style="font-size:0.65rem;">Management</small>
                <a onclick="showSection('upload')" id="nav-upload"><i class="bi bi-cloud-arrow-up me-3"></i> Upload Files</a>
                <a onclick="showSection('manage')" id="nav-manage"><i class="bi bi-folder-plus me-3"></i> Manage Storage</a>
                <a onclick="showSection('users')" id="nav-users">
                    <i class="bi bi-people me-3"></i> Users Control
                </a>
            <?php endif; ?>
            <a href="library.php">
                <i class="bi bi-play-circle me-3"></i>
                Library
            </a>
            <a href="logout.php" class="text-danger mt-5"><i class="bi bi-power me-3"></i> Logout</a>
        </div>
    </nav>
    <div class="offcanvas offcanvas-start" tabindex="-1" id="mobileMenu">
        <div class="offcanvas-header bg-dark text-white">
            <h5 class="offcanvas-title">Menu</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
        </div>

        <div class="offcanvas-body bg-dark text-white">

            <a class="d-block mb-3 text-white text-decoration-none"
                onclick="mobileNav('dashboard')">
                Dashboard
            </a>

            <?php if ($role_type == 1): ?>

                <a class="d-block mb-3 text-white text-decoration-none"
                    onclick="mobileNav('upload')">
                    Upload Files
                </a>

                <a class="d-block mb-3 text-white text-decoration-none"
                    onclick="mobileNav('manage')">
                    Manage Storage
                </a>

                <a class="d-block mb-3 text-white text-decoration-none"
                    onclick="mobileNav('users')">
                    Users Control
                </a>

            <?php endif; ?>

            <a href="library.php" class="d-block mb-3 text-white text-decoration-none">
                Library
            </a>

            <a href="logout.php" class="d-block text-danger text-decoration-none">
                Logout
            </a>

        </div>
    </div>

    <main class="main-content">
        <div class="container-fluid">

            <!-- ══ SECTION 1: DASHBOARD (unchanged) ══════════════════════════════ -->
            <div id="dashboard-section" class="content-section active">
                <header class="d-flex justify-content-between align-items-center mb-5">
                    <div>
                        <h2 class="fw-bold mb-1">System Overview</h2>
                    </div>
                </header>
                <div class="row g-4 mb-4">
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="card stat-card p-4">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h6 class="text-muted small text-uppercase fw-bold">Disk Used</h6>
                                    <h3 class="fw-bold mb-0" id="live-used-percent"><?php echo $usedPercent; ?>%</h3>
                                </div>
                                <div class="bg-danger bg-opacity-10 p-3 rounded-circle">
                                    <i class="bi bi-hdd-fill text-danger fs-4"></i>
                                </div>
                            </div>
                            <div class="progress mt-3" style="height:6px;">
                                <div id="live-progress-bar" class="progress-bar bg-danger" style="width:<?php echo $usedPercent; ?>%"></div>
                            </div>
                            <small class="text-muted mt-2 d-block" id="live-used-info"><?php echo formatSize($usedSpace); ?> used of <?php echo formatSize($totalSpace); ?></small>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="card stat-card p-4">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h6 class="text-muted small text-uppercase fw-bold">Directories</h6>
                                    <h3 class="fw-bold mb-0" id="live-total-folders"><?php echo $totalFolders; ?></h3>
                                </div>
                                <div class="bg-primary bg-opacity-10 p-3 rounded-circle">
                                    <i class="bi bi-folder-fill text-primary fs-4"></i>
                                </div>
                            </div>
                            <small class="text-muted mt-2 d-block">Active folders</small>
                        </div>
                    </div>
                </div>
                <div class="row g-4">
                    <div class="col-lg-8">
                        <div class="card border-0 shadow-sm p-4 h-100">
                            <h5 class="fw-bold mb-4">File Distribution Analysis</h5>
                            <div class="chart-container"><canvas id="fileChart"></canvas></div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card border-0 shadow-sm p-4 h-100">
                            <h5 class="fw-bold mb-4">Folders List</h5>
                            <div class="list-group list-group-flush" id="live-folder-list">
                                <?php foreach ($folderNames as $i => $name): ?>
                                    <div class="list-group-item d-flex justify-content-between align-items-center px-0 border-light">
                                        <div class="d-flex align-items-center">
                                            <i class="bi bi-folder2 text-warning fs-4 me-3"></i>
                                            <span class="fw-bold"><?php echo htmlspecialchars($name); ?></span>
                                        </div>
                                        <span class="badge bg-light text-dark border rounded-pill"><?php echo $fileCounts[$i]; ?> files</span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ══ SECTION 2: UPLOAD CENTER (unchanged) ══════════════════════════ -->
            <div id="upload-section" class="content-section">
                <header class="mb-5">
                    <h2 class="fw-bold mb-1">Upload Center</h2>
                </header>
                <div class="row g-4">
                    <div class="col-lg-7">
                        <div class="card border-0 shadow-sm p-4">
                            <label class="form-label fw-bold">1. Select Target Folder</label>

                            <select id="targetFolder" name="targetFolder" class="form-select mb-4 py-2">

                                <?php foreach ($directories as $dir): ?>

                                    <option value="<?php echo $dir; ?>">
                                        <?php echo basename($dir); ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>
                            <label class="form-label fw-bold">2. Choose or Drag Files</label>
                            <div id="dropZone" class="upload-area">
                                <i class="bi bi-cloud-arrow-up fs-1 text-danger"></i>
                                <p class="mt-2 mb-0">Drag & Drop files here or <strong>Click to Browse</strong></p>
                                <input type="file" id="fileInput" multiple class="d-none">
                            </div>
                            <button id="startUploadBtn" class="btn btn-danger w-100 mt-4 py-3 fw-bold d-none">
                                <i class="bi bi-arrow-up-circle me-2"></i> START UPLOAD
                            </button>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <h5 class="fw-bold mb-3">Upload Queue</h5>
                        <div id="queueList"></div>
                    </div>
                </div>
            </div>

            <!-- ══ SECTION 3: MANAGE STORAGE (UPDATED) ═══════════════════════════ -->
            <div id="manage-section" class="content-section">
                <header class="mb-4">
                    <h2 class="fw-bold mb-1">Manage Storage</h2>
                </header>

                <!-- Breadcrumb -->
                <div class="ms-breadcrumb">
                    <span onclick="msLoadRoot()"><i class="bi bi-hdd me-1"></i>storage</span>
                    <span id="ms-breadcrumb-folder"></span>
                </div>

                <!-- Toolbar -->
                <div id="ms-toolbar">
                    <button class="btn btn-danger btn-sm" onclick="msShowCreateFolder()">
                        <i class="bi bi-folder-plus me-1"></i> New Folder
                    </button>
                    <button id="ms-back-btn" class="btn btn-outline-secondary btn-sm d-none" onclick="msLoadRoot()">
                        <i class="bi bi-arrow-left me-1"></i> Back to Root
                    </button>

                </div>

                <!-- Content area -->
                <div id="ms-content"></div>

                <!-- Batch actions floating bar -->
                <div id="ms-batch-bar" class="ms-batch-actions" style="display: none;">
                    <span id="ms-selected-count">0</span> selected
                    <button onclick="msBatchDelete()"><i class="bi bi-trash"></i> Delete</button>
                    <button onclick="msShowBatchMove()"><i class="bi bi-arrow-right-circle"></i> Move</button>
                </div>

                <!-- Move files modal -->
                <div class="modal fade" id="msMoveModal" tabindex="-1">
                    <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h6 class="modal-title fw-bold">Move Selected Files</h6>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <label class="form-label small fw-bold">Destination Folder</label>
                                <select id="ms-move-dest" class="form-select form-select-sm"></select>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-danger btn-sm" onclick="msBatchMoveConfirm()">Move Files</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Create folder modal -->
                <div class="modal fade" id="msCreateModal" tabindex="-1">
                    <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h6 class="modal-title fw-bold">Create Folder</h6>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <label class="form-label small fw-bold">Folder Name</label>
                                <input type="text" id="ms-new-folder-name" class="form-control form-control-sm" placeholder="my-folder">
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-danger btn-sm" onclick="msCreateConfirm()">Create</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- /manage-section -->

            <!-- ══ SECTION 4: USERS CONTROL ═══════════════════════════ -->
            <div id="users-section" class="content-section">

                <header class="mb-4">
                    <h2 class="fw-bold mb-1">Users Control</h2>
                </header>

                <!-- Add User -->
                <div class="card border-0 shadow-sm p-4 mb-4">

                    <div class="row g-3">

                        <div class="col-md-3">
                            <label class="form-label fw-bold small">Username</label>
                            <input type="text"
                                id="uc-username"
                                class="form-control"
                                placeholder="Enter username">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label fw-bold small">Password</label>
                            <input type="password"
                                id="uc-password"
                                class="form-control"
                                placeholder="Enter password">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label fw-bold small">Role</label>

                            <select id="uc-role" class="form-select">
                                <option value="1">Administrator</option>
                                <option value="2" selected>User</option>
                            </select>
                        </div>

                        <div class="col-md-3 d-flex align-items-end">
                            <button class="btn btn-danger w-100"
                                onclick="ucAddUser()">

                                <i class="bi bi-person-plus me-1"></i>
                                Add User

                            </button>
                        </div>

                    </div>

                </div>

                <!-- Users Table -->
                <div class="card border-0 shadow-sm">

                    <div class="table-responsive">

                        <table class="table table-hover align-middle mb-0">

                            <thead class="table-light">

                                <tr>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>Role</th>
                                    <th>Last Login</th>
                                    <th>Created</th>
                                    <th width="260">Actions</th>
                                </tr>

                            </thead>

                            <tbody id="uc-users-body"></tbody>

                        </table>

                    </div>

                </div>

            </div>
        </div>
    </main>

    <!-- JS Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
        // ── Navigation  ────────────────────────────────────────────────────
        function showSection(sectionId) {

            document.querySelectorAll('.content-section')
                .forEach(section => {
                    section.classList.remove('active');
                });

            document.querySelectorAll('.sidebar a')
                .forEach(link => {
                    link.classList.remove('active');
                });

            document.getElementById(sectionId + '-section')
                .classList.add('active');

            const nav = document.getElementById('nav-' + sectionId);

            if (nav) {
                nav.classList.add('active');
            }

            if (sectionId === 'manage') {
                msLoadRoot();
            }

            if (sectionId === 'users') {
                ucLoadUsers();
            }
        }

        // ── Upload ──────────────────────────────────────────────────
        const dropZone = document.getElementById('dropZone');
        const fileInput = document.getElementById('fileInput');
        const queueList = document.getElementById('queueList');
        const startBtn = document.getElementById('startUploadBtn');
        let selectedFiles = [];

        dropZone.onclick = () => fileInput.click();
        fileInput.onchange = (e) => handleFiles(e.target.files);
        dropZone.ondragover = (e) => {
            e.preventDefault();
            dropZone.style.background = "rgba(233,69,96,0.15)";
        };
        dropZone.ondragleave = () => {
            dropZone.style.background = "rgba(233,69,96,0.05)";
        };
        dropZone.ondrop = (e) => {
            e.preventDefault();
            dropZone.style.background = "rgba(233,69,96,0.05)";
            handleFiles(e.dataTransfer.files);
        };

        function handleFiles(files) {
            for (let file of files) {
                const fileId = 'file-' + Math.random().toString(36).substr(2, 9);
                selectedFiles.push({
                    id: fileId,
                    fileData: file
                });
                const item = document.createElement('div');
                item.className = 'file-list-item';
                item.id = fileId;
                item.innerHTML = `
            <div class="d-flex justify-content-between align-items-center mb-1">
                <span class="text-truncate small fw-bold" style="max-width:70%;">${file.name}</span>
                <div class="d-flex align-items-center">
                    <span class="status-text small text-muted me-2">Pending</span>
                    <i class="bi bi-x-circle-fill remove-btn fs-5" onclick="removeFile('${fileId}')"></i>
                </div>
            </div>
            <div class="progress" style="height:6px;">
                <div class="progress-bar bg-danger" role="progressbar" style="width:0%"></div>
            </div>`;
                queueList.appendChild(item);
            }
            toggleUploadButton();
        }

        function removeFile(id) {
            selectedFiles = selectedFiles.filter(f => f.id !== id);
            const el = document.getElementById(id);
            if (el) {
                el.style.opacity = '0';
                el.style.transform = 'translateX(20px)';
                setTimeout(() => {
                    el.remove();
                    toggleUploadButton();
                }, 300);
            }
        }

        function toggleUploadButton() {
            startBtn.classList.toggle('d-none', selectedFiles.length === 0);
        }

        startBtn.onclick = async () => {
            startBtn.disabled = true;
            document.querySelectorAll('.remove-btn').forEach(b => b.style.display = 'none');
            const targetFolder = document.getElementById('targetFolder').value;
            let uploadPromises = [];
            for (let fileObj of selectedFiles) {
                const promise = new Promise((resolve) => {
                    const formData = new FormData();
                    formData.append('files[]', fileObj.fileData);
                    formData.append('target_folder', targetFolder);
                    const xhr = new XMLHttpRequest();
                    xhr.open('POST', 'home.php', true);
                    xhr.upload.onprogress = (e) => {
                        if (e.lengthComputable) {
                            const pct = (e.loaded / e.total) * 100;
                            const el = document.getElementById(fileObj.id);
                            if (el) el.querySelector('.progress-bar').style.width = pct + '%';
                        }
                    };
                    xhr.onload = function() {
                        try {
                            const res = JSON.parse(xhr.responseText);

                            const el = document.getElementById(fileObj.id);
                            if (!el) return;

                            const st = el.querySelector('.status-text');

                            const item = res.find(r => r.file === fileObj.fileData.name);

                            if (item && item.status === 'success') {
                                st.innerHTML = 'Completed';
                                st.classList.add('status-completed');
                                el.querySelector('.progress-bar').classList.replace('bg-danger', 'bg-success');
                            } else {
                                st.innerHTML = 'Failed';
                                st.style.color = 'red';
                            }

                        } catch (e) {
                            console.log(e);
                        }

                        resolve();
                    };
                    xhr.send(formData);
                });
                uploadPromises.push(promise);
            }
            await Promise.all(uploadPromises);
            setTimeout(() => {
                queueList.innerHTML = '';
                selectedFiles = [];
                toggleUploadButton();
                startBtn.disabled = false;
                fetchStats();
            }, 1500);
        };

        // ── Dashboard  ────────────────────────────────────────────────
        const ctx = document.getElementById('fileChart').getContext('2d');
        const fileChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($folderNames); ?>,
                datasets: [{
                    label: 'Files Count',
                    data: <?php echo json_encode($fileCounts); ?>,
                    backgroundColor: '#e94560',
                    borderRadius: 8,
                    barThickness: 30
                }]
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: '#eee'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });

        function fetchStats() {
            const fd = new FormData();
            fd.append('action', 'get_stats');
            fetch('home.php', {
                method: 'POST',
                body: fd
            }).then(r => r.json()).then(data => {
                document.getElementById('live-used-percent').innerText = data.usedPercent + '%';
                document.getElementById('live-progress-bar').style.width = data.usedPercent + '%';
                document.getElementById('live-used-info').innerText = data.usedSizeFormatted + ' used of ' + data.totalSizeFormatted;
                document.getElementById('live-total-folders').innerText = data.totalFolders;
                fileChart.data.labels = data.folderNames;
                fileChart.data.datasets[0].data = data.fileCounts;
                fileChart.update();
                let listHtml = '';
                data.folderNames.forEach((name, i) => {
                    listHtml += `<div class="list-group-item d-flex justify-content-between align-items-center px-0 border-light">
                <div class="d-flex align-items-center"><i class="bi bi-folder2 text-warning fs-4 me-3"></i><span class="fw-bold">${escapeHtml(name)}</span></div>
                <span class="badge bg-light text-dark border rounded-pill">${data.fileCounts[i]} files</span></div>`;
                });
                document.getElementById('live-folder-list').innerHTML = listHtml;
            }).catch(e => console.error(e));
        }
        setInterval(fetchStats, 5000);


        let msCurrentFolder = null;
        let msAllFolders = [];
        let msSelectedFiles = new Set();

        async function msPost(data) {
            const fd = new FormData();
            Object.keys(data).forEach(k => fd.append(k, data[k]));
            const r = await fetch('home.php', {
                method: 'POST',
                body: fd
            });
            return r.json();
        }

        function updateBatchBar() {
            const count = msSelectedFiles.size;
            const bar = document.getElementById('ms-batch-bar');
            if (count > 0) {
                bar.style.display = 'flex';
                document.getElementById('ms-selected-count').innerText = count;
            } else {
                bar.style.display = 'none';
            }
            const selectAllCheckbox = document.getElementById('ms-select-all-checkbox');
            if (selectAllCheckbox) {
                const totalFiles = document.querySelectorAll('.ms-file-checkbox').length;
                selectAllCheckbox.checked = count > 0 && count === totalFiles;
                selectAllCheckbox.indeterminate = count > 0 && count < totalFiles;
            }
        }

        function msToggleSelectAll() {
            const checkboxes = document.querySelectorAll('.ms-file-checkbox');
            const allChecked = Array.from(checkboxes).every(cb => cb.checked);
            checkboxes.forEach(cb => {
                cb.checked = !allChecked;
                const fileName = cb.getAttribute('data-file');
                if (!allChecked) {
                    msSelectedFiles.add(fileName);
                } else {
                    msSelectedFiles.delete(fileName);
                }
            });
            updateBatchBar();
        }

        async function msLoadRoot() {
            msCurrentFolder = null;
            msSelectedFiles.clear();
            updateBatchBar();
            document.getElementById('ms-breadcrumb-folder').textContent = '';
            document.getElementById('ms-back-btn').classList.add('d-none');
            const data = await msPost({
                action: 'ms_list_root'
            });
            msAllFolders = (data.folders || []).map(f => f.name);
            const content = document.getElementById('ms-content');
            if (!data.folders || data.folders.length === 0) {
                content.innerHTML = '<div class="ms-empty"><i class="bi bi-folder2-open fs-1 d-block mb-2"></i>No folders yet. Create one!</div>';
                return;
            }
            content.innerHTML = data.folders.map(f => `
        <div class="ms-folder-card">
            <div class="d-flex align-items-center gap-3">
                <i class="bi bi-folder-fill text-warning fs-3"></i>
                <div>
                    <div class="folder-name" onclick="msOpenFolder('${escapeHtml(f.name)}')">${escapeHtml(f.name)}</div>
                    <small class="text-muted">${f.count} file(s), ${f.subfolders} subfolder(s)</small>
                </div>
            </div>
            <button class="btn btn-outline-danger btn-sm" onclick="msDeleteFolder('${escapeHtml(f.name)}')">
                <i class="bi bi-trash"></i>
            </button>
        </div>`).join('');
        }

        async function msOpenFolder(folderName) {
            msCurrentFolder = folderName;
            msSelectedFiles.clear();
            updateBatchBar();
            document.getElementById('ms-breadcrumb-folder').innerHTML = ` &rsaquo; <strong>${escapeHtml(folderName)}</strong>`;
            document.getElementById('ms-back-btn').classList.remove('d-none');
            const data = await msPost({
                action: 'ms_list_files',
                folder: folderName
            });
            const content = document.getElementById('ms-content');
            if (!data.files || data.files.length === 0) {
                content.innerHTML = '<div class="ms-empty"><i class="bi bi-file-earmark fs-1 d-block mb-2"></i>This folder is empty.</div>';
                return;
            }
            content.innerHTML = `<div class="mb-2 small text-muted ps-2">✓ Click checkboxes to select multiple files for batch operations</div>` +
                data.files.map(f => `
        <div class="ms-file-row">
            <input type="checkbox" class="ms-file-checkbox" data-file="${escapeHtml(f.name)}" onchange="msToggleFile('${escapeHtml(f.name)}', this.checked)">
            <i class="bi ${f.is_dir ? 'bi-folder-fill text-warning' : 'bi-file-earmark text-secondary'} fs-4"></i>
            <div class="flex-grow-1">
                <div class="fw-bold small">${escapeHtml(f.name)}</div>
                <small class="text-muted">${f.size} &bull; ${f.mtime}</small>
            </div>
            ${!f.is_dir ? `
            <button class="btn btn-outline-secondary btn-sm" onclick="msShowSingleMove('${escapeHtml(f.name)}')" title="Move">
                <i class="bi bi-arrow-right-circle"></i>
            </button>
            <button class="btn btn-outline-danger btn-sm" onclick="msDeleteFile('${escapeHtml(f.name)}')" title="Delete">
                <i class="bi bi-trash"></i>
            </button>` : ''}
        </div>`).join('');
        }

        function msToggleFile(fileName, isChecked) {
            if (isChecked) {
                msSelectedFiles.add(fileName);
            } else {
                msSelectedFiles.delete(fileName);
            }
            updateBatchBar();
        }

        async function msDeleteFolder(name) {
            if (!confirm(`Delete folder "${name}" and ALL its contents?`)) return;
            const data = await msPost({
                action: 'ms_delete_folder',
                folder: name
            });
            if (data.success) {
                msLoadRoot();
                fetchStats();
            } else alert('Error: ' + (data.error || 'unknown'));
        }

        async function msDeleteFile(name) {
            if (!confirm(`Delete file "${name}"?`)) return;
            const data = await msPost({
                action: 'ms_delete_file',
                folder: msCurrentFolder,
                file: name
            });
            if (data.success) {
                msOpenFolder(msCurrentFolder);
                fetchStats();
            } else alert('Error: ' + (data.error || 'unknown'));
        }

        async function msBatchDelete() {
            const files = Array.from(msSelectedFiles);
            if (files.length === 0) return;
            if (!confirm(`Delete ${files.length} selected file(s)?`)) return;
            const data = await msPost({
                action: 'ms_delete_files',
                folder: msCurrentFolder,
                files: JSON.stringify(files)
            });
            if (data.success) {
                msSelectedFiles.clear();
                msOpenFolder(msCurrentFolder);
                fetchStats();
            } else alert('Error: ' + (data.error || 'unknown'));
        }

        function msShowSingleMove(fileName) {
            msSelectedFiles.clear();
            msSelectedFiles.add(fileName);
            msShowBatchMove();
        }

        function msShowBatchMove() {
            if (msSelectedFiles.size === 0) return;
            const sel = document.getElementById('ms-move-dest');
            sel.innerHTML = msAllFolders
                .filter(f => f !== msCurrentFolder)
                .map(f => `<option value="${escapeHtml(f)}">${escapeHtml(f)}</option>`).join('');
            if (sel.innerHTML === '') {
                alert('No destination folders available!');
                return;
            }
            new bootstrap.Modal(document.getElementById('msMoveModal')).show();
        }

        async function msBatchMoveConfirm() {
            const dest = document.getElementById('ms-move-dest').value;
            const files = Array.from(msSelectedFiles);
            bootstrap.Modal.getInstance(document.getElementById('msMoveModal')).hide();
            const data = await msPost({
                action: 'ms_move_files',
                src_folder: msCurrentFolder,
                dest_folder: dest,
                files: JSON.stringify(files)
            });
            if (data.success) {
                msSelectedFiles.clear();
                msOpenFolder(msCurrentFolder);
                fetchStats();
            } else alert('Error: ' + (data.error || 'unknown'));
        }

        function msShowCreateFolder() {
            document.getElementById('ms-new-folder-name').value = '';
            new bootstrap.Modal(document.getElementById('msCreateModal')).show();
        }

        async function msCreateConfirm() {
            const name = document.getElementById('ms-new-folder-name').value.trim();
            const parent = msCurrentFolder || '';
            bootstrap.Modal.getInstance(document.getElementById('msCreateModal')).hide();
            if (!name) return;
            const data = await msPost({
                action: 'ms_create_folder',
                parent,
                name
            });
            if (data.success) {
                msCurrentFolder ? msOpenFolder(msCurrentFolder) : msLoadRoot();
                fetchStats();
            } else alert('Error: ' + (data.error || 'unknown'));
        }

        function escapeHtml(s) {
            return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        }
        // ── USERS CONTROL ───────────────────────────────────────

        async function ucLoadUsers() {

            const data = await msPost({
                action: 'uc_list_users'
            });

            let html = '';

            data.users.forEach(user => {

                html += `
        <tr>

            <td>${user.id}</td>

            <td>
                <strong>${escapeHtml(user.username)}</strong>
            </td>

            <td>

                <select
                    class="form-select form-select-sm"
                    onchange="ucChangeRole(${user.id}, this.value)">

                    <option value="1"
                        ${user.role_type == 1 ? 'selected' : ''}>

                        Administrator

                    </option>

                    <option value="2"
                        ${user.role_type == 2 ? 'selected' : ''}>

                        User

                    </option>

                </select>

            </td>

            <td>${user.last_login || '-'}</td>

            <td>${user.created_at}</td>

            <td>

                <div class="d-flex gap-2">

                    <button
                        class="btn btn-outline-primary btn-sm"
                        onclick="ucChangePassword(${user.id})">

                        <i class="bi bi-key"></i>

                    </button>

                    <button
                        class="btn btn-outline-danger btn-sm"
                        onclick="ucDeleteUser(${user.id}, '${escapeHtml(user.username)}')">

                        <i class="bi bi-trash"></i>

                    </button>

                </div>

            </td>

        </tr>
        `;
            });

            document.getElementById('uc-users-body').innerHTML = html;
        }

        async function ucAddUser() {

            const username = document
                .getElementById('uc-username')
                .value
                .trim();

            const password = document
                .getElementById('uc-password')
                .value;

            const role = document
                .getElementById('uc-role')
                .value;

            if (!username || !password) {

                alert('Please fill all fields');

                return;
            }

            const data = await msPost({

                action: 'uc_add_user',
                username: username,
                password: password,
                role_type: role

            });

            if (data.success) {

                document.getElementById('uc-username').value = '';
                document.getElementById('uc-password').value = '';

                ucLoadUsers();

            } else {

                alert(data.error || 'Error');
            }
        }

        async function ucDeleteUser(id, username) {

            if (!confirm(`Delete user "${username}" ?`)) {
                return;
            }

            const data = await msPost({

                action: 'uc_delete_user',
                id: id

            });

            if (data.success) {

                ucLoadUsers();

            } else {

                alert(data.error || 'Error');
            }
        }

        async function ucChangePassword(id) {

            const password = prompt('Enter new password');

            if (!password) {
                return;
            }

            const data = await msPost({

                action: 'uc_change_password',
                id: id,
                password: password

            });

            if (data.success) {

                alert('Password updated');

            } else {

                alert(data.error || 'Error');
            }
        }

        async function ucChangeRole(id, role) {

            const data = await msPost({

                action: 'uc_change_role',
                id: id,
                role: role

            });

            if (!data.success) {

                alert(data.error || 'Error');
            }
        }

        function loadFoldersLive() {

            const fd = new FormData();
            fd.append('action', 'uc_folder_list');

            fetch('home.php', {
                    method: 'POST',
                    body: fd
                })
                .then(r => r.json())
                .then(data => {

                    const select = document.getElementById('targetFolder');

                    const currentValue = select.value;

                    select.innerHTML = '';

                    data.folders.forEach(folder => {

                        const opt = document.createElement('option');
                        opt.value = folder;
                        opt.textContent = folder;

                        select.appendChild(opt);
                    });

                    if (currentValue) {
                        select.value = currentValue;
                    }
                });
        }

        loadFoldersLive();

        setInterval(loadFoldersLive, 5000);

        const menuBtn = document.getElementById('menuBtn');
        const menuIcon = document.getElementById('menuIcon');
        const mobileMenu = document.getElementById('mobileMenu');

        const offcanvas = new bootstrap.Offcanvas(mobileMenu);

        function openMenu() {
            offcanvas.show();
            menuIcon.className = 'bi bi-x-lg fs-3';
        }

        function closeMenu() {
            offcanvas.hide();
            menuIcon.className = 'bi bi-list fs-3';
        }

        menuBtn.addEventListener('click', () => {
            if (mobileMenu.classList.contains('show')) {
                closeMenu();
            } else {
                openMenu();
            }
        });

        mobileMenu.addEventListener('hidden.bs.offcanvas', () => {
            menuIcon.className = 'bi bi-list fs-3';
        });

        mobileMenu.addEventListener('shown.bs.offcanvas', () => {
            menuIcon.className = 'bi bi-x-lg fs-3';
        });

        function mobileNav(section) {
            offcanvas.hide();
            showSection(section);
        }
    </script>
</body>

</html>