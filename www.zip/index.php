<?php
session_start();

require_once __DIR__ . '/include/db_con.php';

if (isset($_SESSION['user_id'])) {
    header("Location: home.php");
    exit();
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!empty($username) && !empty($password)) {
        $stmt = $pdo->prepare("SELECT id, username, password, role_type FROM users WHERE username = :user LIMIT 1");
        $stmt->bindValue(':user', $username, PDO::PARAM_STR);
        $stmt->execute();
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $updateStmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = :id");
            $updateStmt->bindValue(':id', $user['id'], PDO::PARAM_INT);
            $updateStmt->execute();

            session_regenerate_id(true);
            $_SESSION['user_id']   = (int)$user['id'];
            $_SESSION['username']  = $user['username'];
            $_SESSION['role_type'] = (int)$user['role_type'];

            header("Location: home.php");
            exit();
        } else {
            $error = "Username or password is wrong.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="En">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Media Server - Login </title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Tajawal', sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            overflow: hidden;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.5);
        }
        .login-card h2 {
            color: #fff;
            font-weight: 700;
            margin-bottom: 30px;
            text-align: center;
            letter-spacing: 1px;
        }
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: none;
            border-radius: 10px;
            color: #fff;
            padding: 12px 20px;
            margin-bottom: 20px;
        }
        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            box-shadow: 0 0 10px rgba(0, 123, 255, 0.5);
            color: #fff;
        }
        .btn-primary {
            background: #e94560;
            border: none;
            border-radius: 10px;
            padding: 12px;
            width: 100%;
            font-weight: 700;
            transition: 0.3s;
        }
        .btn-primary:hover {
            background: #ff4d6d;
            transform: translateY(-2px);
        }
        .error-msg {
            color: #ff6b6b;
            font-size: 0.9rem;
            text-align: center;
            margin-bottom: 15px;
        }
        @media (max-width: 576px) {
            .login-card {
                margin: 20px;
                padding: 30px;
            }
        }
    </style>
</head>
<body>

    <div class="login-card">
        <h2>Media <span style="color: #e94560;">Server</span></h2>
        
        <?php if($error): ?>
            <div class="error-msg"><?php echo $error; ?></div>
        <?php endif; ?>

        <form action="" method="POST" autocomplete="off">
            <div class="mb-3">
                <input type="text" name="username" class="form-control" placeholder="‘Username" required>
            </div>
            <div class="mb-3">
                <input type="password" name="password" class="form-control" placeholder="Password" required>
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>
        
        <div class="mt-4 text-center">
            <small style="color: rgba(255,255,255,0.4);">s2000.n &copy; 2026</small>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>