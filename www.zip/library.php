<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$rootPath = 'storage/';
$currentFolder = isset($_GET['folder']) ? basename($_GET['folder']) : null;

function isVideo($file)
{
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    return in_array($ext, ['mp4', 'webm', 'mkv', 'mov', 'avi']);
}

function isImage($file)
{
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    return in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp']);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        body {
            background: #141414;
            color: white;
            font-family: Arial;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 18px;
        }

        .folder {
            position: relative;
            height: 240px;
            border-radius: 14px;
            overflow: hidden;
            cursor: pointer;
            transition: .25s;
            background: #222;
        }

        .folder:hover {
            transform: scale(1.05);
        }

        .folder img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(to top, rgba(0, 0, 0, .9), transparent);
        }

        .name {
            position: absolute;
            bottom: 10px;
            left: 10px;
            font-weight: bold;
        }

        .card-media {
            position: relative;
            border-radius: 12px;
            overflow: hidden;
            background: #111;
            cursor: pointer;
        }

        .card-media {
            position: relative;
            border-radius: 12px;
            overflow: hidden;
            background: #111;
            cursor: pointer;

            display: flex;
            flex-direction: column;
        }

        .card-media img {
            width: 100%;
            height: auto;
            object-fit: contain;
            background: black;
        }

        .card-media video {
            width: 100%;
            height: auto;
            background: black;
        }

        .file-box {
            width: 100%;
            height: 200px;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #222;
        }

        .select-box {
            position: absolute;
            top: 10px;
            left: 10px;
            transform: scale(1.3);
            display: none;
            z-index: 2;
        }

        .select-bar {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: #e50914;
            padding: 10px 15px;
            border-radius: 30px;
            display: none;
            gap: 10px;
            align-items: center;
            z-index: 999;
        }

        .select-bar button {
            border: none;
            padding: 6px 12px;
            border-radius: 20px;
        }

        .modal-content {
            background: black;
        }

        .modal-body {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        #viewerContent img,
        #viewerContent video {
            max-width: 100%;
            max-height: 100vh;
            object-fit: contain;
        }

        .close-btn {
            position: absolute;
            top: 15px;
            right: 15px;
            z-index: 9999;
        }

        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;

            padding: 8px 14px;
            border-radius: 25px;

            background: rgba(255, 255, 255, 0.08);
            color: white;

            text-decoration: none;
            font-weight: 600;

            transition: 0.2s;
            backdrop-filter: blur(6px);
        }

        .back-btn:hover {
            background: #e50914;
            color: white;
            transform: translateX(-3px);
        }

        .card-media.selected {
            outline: 3px solid #e50914;
            transform: scale(1.03);
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-dark px-4 py-3" style="background:#000;">
        <a href="library.php" style="color:#e50914;font-weight:bold;font-size:22px;text-decoration:none;">
            Media Server
        </a>

        <a href="home.php" class="btn btn-outline-light btn-sm">Dashboard</a>
    </nav>

    <div class="container-fluid px-4 mt-4">

        <?php if (!$currentFolder): ?>

            <h3 class="mb-4">Folders</h3>

            <div class="grid">

                <?php
                $folders = array_filter(glob($rootPath . '*'), 'is_dir');

                foreach ($folders as $folder):
                    $name = basename($folder);
                    $files = array_diff(scandir($folder), ['.', '..']);

                    $preview = null;

                    foreach ($files as $f) {
                        if (isImage($folder . '/' . $f)) {
                            $preview = $folder . '/' . $f;
                            break;
                        }
                    }

                    if (!$preview) {
                        $preview = "assets/no-preview.jpg";
                    }
                ?>

                    <a href="library.php?folder=<?= urlencode($name) ?>" style="text-decoration:none;color:white;">
                        <div class="folder">
                            <img src="<?= $preview ?>">
                            <div class="overlay"></div>
                            <div class="name"><?= htmlspecialchars($name) ?></div>
                        </div>
                    </a>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <?php
            $path = $rootPath . $currentFolder;

            if (!is_dir($path)) {
                echo "<div class='alert alert-danger'>Folder not found</div>";
            } else {

                $files = array_diff(scandir($path), ['.', '..']);
            ?>

                <div class="d-flex justify-content-between mb-3">
                    <a href="library.php" class="back-btn">
                        <i class="bi bi-arrow-left"></i>
                        Back
                    </a>

                    <button id="selectBtn" class="btn btn-danger btn-sm" onclick="toggleSelect()">
                        Select
                    </button>
                </div>

                <div class="grid">

                    <?php foreach ($files as $file):

                        $full = $path . '/' . $file;
                        if (is_dir($full)) continue;
                    ?>

                        <div class="card-media" onclick="toggleFileSelect(this)">
                            <input type="checkbox" class="select-box" value="<?= $full ?>">

                            <?php if (isVideo($full)): ?>
                                <video onclick="openMedia(this.querySelector('source').src)">
                                    <source src="<?= $full ?>">
                                </video>

                            <?php elseif (isImage($full)): ?>
                                <img src="<?= $full ?>" onclick="openMedia(this.src)">

                            <?php else: ?>
                                <div style="height:220px;display:flex;justify-content:center;align-items:center;">
                                    <i class="bi bi-file-earmark fs-1"></i>
                                </div>
                            <?php endif; ?>

                        </div>

                    <?php endforeach; ?>

                </div>

            <?php } ?>

        <?php endif; ?>

    </div>

    <div class="select-bar" id="selectBar">
        <span id="count">0 selected</span>
        <button onclick="downloadSelected()">Download</button>
    </div>

    <div class="modal fade" id="viewer" tabindex="-1">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content">

                <button class="btn btn-light close-btn" onclick="closeViewer()">✖</button>

                <div class="modal-body">
                    <div id="viewerContent"></div>
                </div>

            </div>
        </div>
    </div>

    <script>
        let selectMode = false;

        function toggleSelect() {
            selectMode = !selectMode;

            document.querySelectorAll('.select-box').forEach(cb => {
                cb.style.display = selectMode ? 'block' : 'none';
            });

            document.getElementById('selectBar').style.display =
                selectMode ? 'flex' : 'none';

            document.getElementById('selectBtn').innerText =
                selectMode ? 'Unselect' : 'Select';

            if (!selectMode) {
                document.querySelectorAll('.select-box').forEach(cb => {
                    cb.checked = false;
                });

                document.querySelectorAll('.card-media').forEach(card => {
                    card.classList.remove('selected');
                });

                updateSelectedCount();
            }
        }

        document.addEventListener('change', updateSelectedCount);

        function downloadSelected() {
            let files = [];

            document.querySelectorAll('.select-box:checked').forEach(cb => {
                files.push(cb.value);
            });

            if (files.length === 0) return;

            let form = document.createElement('form');
            form.method = 'POST';
            form.action = 'download_zip.php';

            files.forEach(f => {
                let input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'files[]';
                input.value = f;
                form.appendChild(input);
            });

            document.body.appendChild(form);
            form.submit();
            document.body.removeChild(form);
        }

        function openMedia(src) {
            if (selectMode) return;

            let ext = src.split('.').pop().toLowerCase();

            let html = '';

            if (['mp4', 'webm', 'mkv', 'mov', 'avi'].includes(ext)) {
                html = `<video controls autoplay><source src="${src}"></video>`;
            } else {
                html = `<img src="${src}">`;
            }

            document.getElementById('viewerContent').innerHTML = html;
            new bootstrap.Modal(document.getElementById('viewer')).show();
        }

        function closeViewer() {
            let modal = bootstrap.Modal.getInstance(document.getElementById('viewer'));
            if (modal) modal.hide();
            document.getElementById('viewerContent').innerHTML = '';
        }

        document.addEventListener('keydown', e => {
            if (e.key === "Escape") closeViewer();
        });

        document.getElementById('viewer').addEventListener('click', function(e) {
            if (e.target === this) closeViewer();
        });

        function toggleFileSelect(card) {
            if (!selectMode) return;

            const checkbox = card.querySelector('.select-box');

            checkbox.checked = !checkbox.checked;

            updateSelectedCount();
        }

        function updateSelectedCount() {
            let count = document.querySelectorAll('.select-box:checked').length;
            document.getElementById('count').innerText = count + " selected";
        }

        function toggleFileSelect(card) {
            if (!selectMode) return;

            const checkbox = card.querySelector('.select-box');

            checkbox.checked = !checkbox.checked;

            card.classList.toggle('selected', checkbox.checked);

            updateSelectedCount();
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>