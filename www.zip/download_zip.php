<?php
if (!isset($_POST['files'])) {
    exit("No files selected");
}

$files = $_POST['files'];

$zip = new ZipArchive();
$zipName = 'download_' . time() . '.zip';
$tmpFile = sys_get_temp_dir() . '/' . $zipName;

if ($zip->open($tmpFile, ZipArchive::CREATE) !== TRUE) {
    exit("Cannot create zip");
}

foreach ($files as $file) {
    if (file_exists($file)) {
        $zip->addFile($file, basename($file));
    }
}

$zip->close();

header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="'.$zipName.'"');
header('Content-Length: ' . filesize($tmpFile));

readfile($tmpFile);
unlink($tmpFile);
exit;
?>